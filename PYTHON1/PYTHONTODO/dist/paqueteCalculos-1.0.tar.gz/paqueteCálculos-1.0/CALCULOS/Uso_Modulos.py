from CALCULOS.POTENCIA_REDONDEO.potencia_redondeo import *
potencia (20,10)
redondear(10.2)