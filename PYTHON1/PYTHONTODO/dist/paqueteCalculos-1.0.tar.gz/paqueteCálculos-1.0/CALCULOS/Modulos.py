#MÓDULOS#
def sumar(op1, op2):
    print("El resultado de la suma es: ", op1 + op2)
def restar(op1, op2):
    print("El resultado de la resta es: ", op1 - op2)
def multiplicar(op1, op2):
    print("El resultado de la multiplicación es: ", op1 * op2)
def potencia(base, exponente):
    print("El resultado de la potencia es: ", base**exponente)
def dividir(dividendo, divisor):
    print("El resultado de la división es: ", dividendo/divisor)
def redondear(numero):
    print("El resultado del redondeo es: ", round(numero))