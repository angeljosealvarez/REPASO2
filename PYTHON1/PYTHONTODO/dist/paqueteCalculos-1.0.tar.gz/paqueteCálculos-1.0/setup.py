from setuptools import setup

setup(
    name= "paqueteCálculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="Juan",
    author_email= "angeljosealvarezperezz@gmail.com",
    url= "www.pildorasinformáticas.es",
    packages=["CALCULOS","CALCULOS.POTENCIA_REDONDEO"]
)